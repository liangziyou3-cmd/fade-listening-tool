# Review report

Schema version: `2.0.0`.

Structural validation: **passed**.

Linguistic annotations: 60 published concepts, 108 cue-local occurrences, 26 repeated concepts. 3 zero-occurrence concepts were excluded from the vocabulary.

## Annotation coverage

- Annotated semantic sentences: 94/228 (41.2%)
- Soft goal: 30%; upper cap: 60%
- Supplemental review attempted: no
- Sentences removed by upper cap: 0
- Below soft goal: no

## Annotation warnings
- `model_unmatched_occurrence`: concept `lc_d9b73e7ff33275da`, sentence `s00004`, surface `estar de suerte`
- `model_unmatched_occurrence`: concept `lc_eae372879924806b`, sentence `s00005`, surface `forma`
- `model_unmatched_occurrence`: concept `lc_b0e1454f414e825a`, sentence `s00002`, surface `leche`
- `model_unmatched_occurrence`: concept `lc_4b63b1b229ef5497`, sentence `s00009`, surface `olvidar`
- `model_unmatched_occurrence`: concept `lc_fc4fb45b57446c51`, sentence `s00045`, surface `visita`
- `model_unmatched_occurrence`: concept `lc_97e6f996d24392e9`, sentence `s00004`, surface `tipo`
- `model_unmatched_occurrence`: concept `lc_f675fdb8e31929e7`, sentence `s00002`, surface `bicicleta`
- `model_unmatched_occurrence`: concept `lc_3ab241fe178c5848`, sentence `s00004`, surface `razón`
- `model_unmatched_occurrence`: concept `lc_f5b5f0711c772809`, sentence `s00043`, surface `bailar`
- `model_unmatched_occurrence`: concept `lc_6e81295a6d905139`, sentence `s00002`, surface `coche`
- `model_unmatched_occurrence`: concept `lc_0653fa8d86d48ce2`, sentence `s00002`, surface `museo`
- `model_unmatched_occurrence`: concept `lc_8f0ed27ec0fe80b8`, sentence `s00043`, surface `dormitorio`
- `model_unmatched_occurrence`: concept `lc_1a6e7fdcd2ac7b53`, sentence `s00032`, surface `entender`
- `model_unmatched_occurrence`: concept `lc_dbf5f53e4d3ff253`, sentence `s00044`, surface `almohada`
- `model_unmatched_occurrence`: concept `lc_90d9612d58a1760d`, sentence `s00002`, surface `baño`
- `model_unmatched_occurrence`: concept `lc_f60b1b662f794443`, sentence `s00004`, surface `maleta`
- `model_unmatched_occurrence`: concept `lc_91765bf6cdcd04f3`, sentence `s00003`, surface `portero`
- `model_unmatched_occurrence`: concept `lc_9b781500763c7dfc`, sentence `s00043`, surface `ropa`
- `model_unmatched_occurrence`: concept `lc_ab52bfa10da03d69`, sentence `s00047`, surface `simpático`
- `model_unmatched_occurrence`: concept `lc_545259d3b04f069f`, sentence `s00047`, surface `amable`
- `model_unmatched_occurrence`: concept `lc_bd9a56cb99002d89`, sentence `s00013`, surface `hambre`
- `model_unmatched_occurrence`: concept `lc_89bff7d803af3452`, sentence `s00048`, surface `enseñar`
- `model_unmatched_occurrence`: concept `lc_38326a60816198b4`, sentence `s00008`, surface `cojín`
- `model_unmatched_occurrence`: concept `lc_39eceb39916ec8ce`, sentence `s00002`, surface `tener que`
- `model_unmatched_occurrence`: concept `lc_a7f3c91d1bf4120f`, sentence `s00041`, surface `ir a`
- `model_unmatched_occurrence`: concept `lc_850c71951e7ba898`, sentence `s00022`, surface `horno`
- `model_unmatched_occurrence`: concept `lc_ec3d7193974f71a9`, sentence `s00047`, surface `fuerte`
- `model_unmatched_occurrence`: concept `lc_cdcc55e2e4d723df`, sentence `s00044`, surface `pierna`
- `model_unmatched_occurrence`: concept `lc_1d7de051c977e413`, sentence `s00044`, surface `pedalear`
- `model_unmatched_occurrence`: concept `lc_393905ddd0a841d5`, sentence `s00050`, surface `imposible`
- `model_unmatched_occurrence`: concept `lc_83bb831d59602ce5`, sentence `s00043`, surface `ducha`
- `model_unmatched_occurrence`: concept `lc_bf0c08a4bfcdc6df`, sentence `s00004`, surface `broma`
- `model_unmatched_occurrence`: concept `lc_9f1e26b88e32e611`, sentence `s00043`, surface `habitación`
- `model_unmatched_occurrence`: concept `lc_b139c082c3af6dc3`, sentence `s00047`, surface `dinero`
- `model_unmatched_occurrence`: concept `lc_24ca643046a67cc4`, sentence `s00006`, surface `cállate`
- `model_unmatched_occurrence`: concept `lc_10d61752e775ea32`, sentence `s00007`, surface `celebrar`
- `model_unmatched_occurrence`: concept `lc_7b8246e033b4b6d7`, sentence `s00049`, surface `carnaval`
- `model_unmatched_occurrence`: concept `lc_8d1bedf357a64ac9`, sentence `s00045`, surface `fiesta`
- `model_unmatched_occurrence`: concept `lc_9c2ad45274709176`, sentence `s00004`, surface `revista`
- `model_unmatched_occurrence`: concept `lc_74dd1676be33ca63`, sentence `s00034`, surface `no tener ni idea`
- `model_unmatched_occurrence`: concept `lc_91f0c7a43ea949b8`, sentence `s00026`, surface `dueña`
- `model_unmatched_occurrence`: concept `lc_53f4368e99198792`, sentence `s00025`, surface `feliz`
- `model_unmatched_occurrence`: concept `lc_bdc74044273ed5a6`, sentence `s00041`, surface `ir de compras`
- `model_unmatched_occurrence`: concept `lc_5f5add8959c64821`, sentence `s00011`, surface `no te lo pierdas`
- `model_unmatched_occurrence`: concept `lc_916449586fa4cc59`, sentence `s00151`, surface `historia`
- `model_unmatched_occurrence`: concept `lc_5ed3ea9e81e9f72a`, sentence `s00151`, surface `compartir`
- `model_unmatched_occurrence`: concept `lc_76c9bd1a4381b6cd`, sentence `s00151`, surface `piso`
- `model_unmatched_occurrence`: concept `lc_714fe9492e7a7b4a`, sentence `s00151`, surface `vecino`
- `model_unmatched_occurrence`: concept `lc_67315b5be933b6ed`, sentence `s00151`, surface `carta`
- `model_unmatched_occurrence`: concept `lc_d9a898b07cc48e10`, sentence `s00151`, surface `acabarse`
- `model_unmatched_occurrence`: concept `lc_944ef3c27631a568`, sentence `s00151`, surface `llorar`
- `model_unmatched_occurrence`: concept `lc_b0126a60a189207a`, sentence `s00151`, surface `correo`
- `model_unmatched_occurrence`: concept `lc_f11a4e0e17991080`, sentence `s00151`, surface `factura`
- `model_unmatched_occurrence`: concept `lc_16936a926b9d532e`, sentence `s00151`, surface `madre`
- `unmatched_occurrence`: concept `lc_202beb17632d7687`, sentence `s00033`, forms `acuerdas`
- `unmatched_occurrence`: concept `lc_0001047826850b8f`, sentence `s00158`, forms `gusta`
- `single_word_sentence_cap`: concept `lc_916449586fa4cc59`, sentence `s00002`
- `single_word_sentence_cap`: concept `lc_67315b5be933b6ed`, sentence `s00004`
- `single_word_sentence_cap`: concept `lc_b06d308ef357ca1c`, sentence `s00047`
- `single_word_sentence_cap`: concept `lc_6e81295a6d905139`, sentence `s00085`
- `single_word_sentence_cap`: concept `lc_6e81295a6d905139`, sentence `s00085`
- `single_word_sentence_cap`: concept `lc_cdcc55e2e4d723df`, sentence `s00158`
- `zero_occurrence_concept_not_published`: concept `lc_916449586fa4cc59`, lemma `historia`
- `zero_occurrence_concept_not_published`: concept `lc_f60b1b662f794443`, lemma `maleta`
- `zero_occurrence_concept_not_published`: concept `lc_cdcc55e2e4d723df`, lemma `pierna`

## Cue translation warnings
- Cue `62`: `cue_translation_context_mismatch`; review 'and any questions' against 'Tall, handsome, and rich.'.
- Cue `129`: `cue_translation_context_mismatch`; review 'Spanish, my name is America' against "My name is America, I'm Sam.".
- Cue `130`: `cue_translation_context_mismatch`; review "I'm Sam, guys" against "My name is America, I'm Sam.".
- Cue `133`: `cue_translation_context_mismatch`; review 'my little cars, you play with cars, yes' against 'You play with cars. Do you play with cars?'.
- Cue `265`: `cue_translation_context_mismatch`; review "but she's in the shower" against 'Pero está en la ducha.'.
- Cue `285`: `cue_translation_context_mismatch`; review 'these fr-' against 'These my friends.'.
- Cue `291`: `cue_translation_context_mismatch`; review "you're rich" against 'Pero Sam, tú eres rico.'.
- Cue `292`: `cue_translation_context_mismatch`; review 'because you want to stay here' against '¿Por qué te quieres quedar aquí?'.
- Cue `293`: `cue_translation_context_mismatch`; review 'I want friends' against 'Quiero amigos, buenos amigos.'.
- Cue `294`: `cue_translation_context_mismatch`; review 'good friends' against 'Quiero amigos, buenos amigos.'.
- Cue `295`: `cue_translation_context_mismatch`; review 'and people like you for your money' against 'Y la gente te quiere por tu dinero.'.
- Cue `297`: `cue_translation_context_mismatch`; review "Santos, don't tell anyone" against 'Santos, no se lo digas a nadie.'.
- Cue `298`: `cue_translation_context_mismatch`; review 'and secret' against 'Y en secreto.'.
- Cue `299`: `cue_translation_context_mismatch`; review "don't tell the girls" against 'No se lo digas a las chicas.'.
- Cue `300`: `cue_translation_context_mismatch`; review 'Tromsoe two' against '¿Sabes?'.
- Cue `301`: `cue_translation_context_mismatch`; review 'you know' against '¿Sabes?'.
- Cue `331`: `cue_translation_context_mismatch`; review 'today they' against 'The sergeant came against them regarding the brother.'.

## Translation alignment warnings
- None.

## Quiz warnings
- `quiz_concept_resolution_failed`: question `q00030`; hint `ir a`; candidates `none`; no unique concept matched the AI hint; human review required
- `quiz_concept_resolution_failed`: question `q00042`; hint `cojín`; candidates `none`; no unique concept matched the AI hint; human review required

## Cultural notes requiring review
- None.

## Semantic review
Issues found.

## Semantic issues
- **medium** `subtitles.json`: Cue translation for sequence 62 ('and any questions') does not align semantically with the source text 'y cualquier duda' linked to the sentence translation 'Tall, handsome, and rich.'
- **medium** `subtitles.json`: Cue translation for sequence 129 ('Spanish, my name is America') shifts meaning compared to the sentence translation 'My name is America, I'm Sam.'
- **low** `subtitles.json`: Cue translation for sequence 133 introduces extra wording ('little') compared to the sentence translation.
